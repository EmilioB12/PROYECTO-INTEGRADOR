#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STRING_LENGTH 255

typedef struct {
    char referencia[MAX_STRING_LENGTH];
    char nombre[MAX_STRING_LENGTH];
    int existente;
    int compra;
    int venta;
} Articulo;

// Funciones
char* leer_cadena(const char *mensaje);
int leer_entero(const char *mensaje, int menor, int mayor);
int leer_campo(FILE *archivo, char *campo, char delimitador);
Articulo* vector_buscar(Articulo *arreglo, int size, const Articulo *referencia);
void vector_quitar(Articulo *arreglo, int *size, Articulo *dato);


int main() {
    Articulo *dato, articulo;
    Articulo arreglo[100];
    int i, n, opcion, contador = 0;
    char campo[MAX_STRING_LENGTH];
    char ruta[] = "Lista_Articulos.txt"; // nombre del archivo .txt a crear en carpeta para almacenamiento de información
    FILE *entrada = fopen(ruta, "r");
    if (entrada != NULL) {
        while (leer_campo(entrada, campo, '\t')) {
            strcpy(articulo.referencia, campo);
            leer_campo(entrada, campo, '\t');
            strcpy(articulo.nombre, campo);
            leer_campo(entrada, campo, '\t');
            articulo.existente = atoi(campo);
            leer_campo(entrada, campo, '\t');
            articulo.compra = atoi(campo);
            leer_campo(entrada, campo, '\n');
            articulo.venta = atoi(campo);
            arreglo[contador] = articulo;
            contador++;
        }
        fclose(entrada);
    }
    do {
        system("cls");
        printf("\n     Programa para registrar articulos\n\n");
        printf("\n  MENU PRINCIPAL\n");
        printf("  1. Ingresar nuevo registro\n");
        printf("  2. Editar registro existente\n");
        printf("  3. Eliminar registro existente\n");
        printf("  4. Guardar registros y salir del sistema\n");

        opcion = leer_entero("\n  Seleccione una opcion: ", 1, 4);
        printf("\n");

		// Condiciones
        // Opción 2: consulta de registros
        // Aparece "No existen registros" cuando el archivo creado está vacío
        if (contador == 0 && opcion != 1 && opcion != 4) {
            printf("\n  No existen registros.\n\n");
            system("pause");
            continue;
        }

        // Ingreso de artículo
        if (opcion < 4) {
            strcpy(articulo.referencia, leer_cadena("  Ingrese la referencia del artículo: "));
            dato = vector_buscar(arreglo, contador, &articulo);
            if (dato != NULL) {
                printf("  referencia        : %s\n", dato->referencia);
                printf("  nombre            : %s\n", dato->nombre);
                printf("  cantidad existente: %d\n", dato->existente);
                printf("  precio de compra  : %d\n", dato->compra);
                printf("  precio de venta   : %d\n\n", dato->venta);
            	contador++;
			}
        }

        // Busca el artículo en archivo para ver si está creado
        // Sino, continua con el ingreso de datos

        if (dato != NULL && opcion == 1)
            printf("\n  Registro Existente.\n");
        else if (dato == NULL && opcion >= 2 && opcion <= 3)
            printf("\nNo se encontro Registro.\n");
        else {
            switch (opcion) {
                case 1:
                    strcpy(articulo.nombre, leer_cadena("  Nombre del producto: "));
                    articulo.existente = leer_entero("  Ingrese cantidad existente: ", 0, INT_MAX);
                    articulo.compra = leer_entero("  Ingrese precio de compra: ", 0, INT_MAX);
                    articulo.venta = leer_entero("  Ingrese precio de venta: ", 0, INT_MAX);
                    arreglo[contador] = articulo;
                    contador++;
                    printf("\n  Registro agregado correctamente.\n");
                    break;
                case 2:
                    printf("\n  Menu de edición de campos\n\n");
                    printf("  1.- Nombre del producto\n");
                    printf("  2.- Cantidad existente\n");
                    printf("  3.- Precio de compra\n");
                    printf("  4.- Precio de venta\n");
                    switch (leer_entero("\n  Seleccione un número de campo a modificar: ", 1, 4)) {
                        case 1:
                            strcpy(dato->nombre, leer_cadena("  Ingrese el nombre del producto: "));
                            break;
                        case 2:
                            dato->existente = leer_entero("  Ingrese cantidad existente: ", 0, INT_MAX);
                            break;
                        case 3:
                            dato->compra = leer_entero("  Ingrese precio de compra: ", 0, INT_MAX);
                            break;
                        case 4:
                            dato->venta = leer_entero("  Ingrese precio de venta: ", 0, INT_MAX);
                            break;
                    }
                    printf("\n  Registro actualizado correctamente.\n");
                    break;
                case 3:
                    vector_quitar(arreglo, &contador, dato);
                    printf("\n  Registro borrado correctamente.\n");
                    break;
                case 4:
                    guardar_registros(ruta, arreglo, contador);
                    printf("\n  Registros guardados correctamente. \n  Saliendo del sistema...\n");
                    break;
            }
        }

        if (opcion < 4 && opcion >= 1) {
            printf("\n\n");
            system("pause");
        }
    } while (opcion != 4);

    FILE *salida = fopen(ruta, "w");
    if (salida != NULL){
        for (i = 0; i < contador; i++) {
            fprintf(salida, "%s\t%s\t%d\t%d\t%d\n", arreglo[i].referencia, arreglo[i].nombre, arreglo[i].existente, arreglo[i].compra, arreglo[i].venta);
        }
        fclose(salida);
    }

    return EXIT_SUCCESS;
}

char* leer_cadena(const char *mensaje) {
    static char cadena[MAX_STRING_LENGTH];
    printf("%s", mensaje);
    fflush(stdin);
    fgets(cadena, sizeof(cadena), stdin);
    int len = strlen(cadena);
    if (len > 0 && cadena[len - 1] == '\n') {
        cadena[len - 1] = '\0';
    }
    return cadena;
}

int leer_entero(const char *mensaje, int menor, int mayor) {
    int entero;
    do {
        printf("%s", mensaje);
        scanf("%d", &entero);
        fflush(stdin);
        if (entero < menor || entero > mayor) {
            printf("  Número no válido.\n");
        }
    } while (entero < menor || entero > mayor);
    return entero;
}

int leer_campo(FILE *archivo, char *cadena, char delimitador) {
    if (fgets(cadena, MAX_STRING_LENGTH, archivo) == NULL) {
        return 0;
    }
    char *tab = strchr(cadena, delimitador);
    if (tab != NULL) {
        *tab = '\0';
    }
    return 1;
}

Articulo* vector_buscar(Articulo *arreglo, int size, const Articulo *referencia) {
    int i;
    for (i = 0; i < size; i++) {
        if (strcmp(referencia->referencia, arreglo[i].referencia) == 0) {
            return &arreglo[i];
        }
    }
    return NULL;
}

void vector_quitar(Articulo *arreglo, int *size, Articulo *dato) {
    int i;
    for (i = 0; i < *size; i++) {
        if (strcmp(dato->referencia, arreglo[i].referencia) == 0) {
            int j;
            for (j = i; j < (*size) - 1; j++) {
                arreglo[j] = arreglo[j + 1];
            }
            (*size)--;
            return;
        }
    }
}

void guardar_registros(const char *ruta, Articulo *arreglo, int size) {
    FILE *salida = fopen(ruta, "w");
    if (salida != NULL) {
        for (int i = 0; i < size; i++) {
            fprintf(salida, "%s\t%s\t%d\t%d\t%d\n", arreglo[i].referencia, arreglo[i].nombre, arreglo[i].existente, arreglo[i].compra, arreglo[i].venta);
        }
        fclose(salida);
    } else {
        printf("Error al abrir el archivo para guardar los registros.\n");
    }
}
